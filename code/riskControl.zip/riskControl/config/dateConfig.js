const dateList = [
  { label: '全部', value: '0' },
  { label: '一个月', value: '30' },
  { label: '三个月', value: '90' },
  { label: '半年', value: '185' },
  { label: '一年', value: '365' },
]

const defaultValue = '0'

// 单一债权人
const concentrationList = [
  { label: '一个月', value: '1' },
  { label: '三个月', value: '3' },
  { label: '半年', value: '6' },
  { label: '一年', value: '12' },
]

const defaultconCentrationValue = '6'